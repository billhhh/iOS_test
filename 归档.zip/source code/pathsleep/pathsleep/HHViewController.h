//
//  HHViewController.h
//  pathsleep
//
//  Created by Eric on 12-2-18.
//  Copyright (c) 2012年 Tian Tian Tai Mei Net Tech (Bei Jing) Lt.d. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface HHViewController : UIViewController
{
    
}
- (IBAction)gosleep:(id)sender;
@end

//
//  ViewController.h
//  my3D
//
//  Created by 黄 hshd1234 on 12-12-29.
//  Copyright (c) 2012年 呼喊. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface ViewController : GLKViewController

@end

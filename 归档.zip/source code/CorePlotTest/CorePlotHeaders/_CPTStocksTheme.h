#import "_CPTXYTheme.h"

@interface _CPTStocksTheme : _CPTXYTheme {
}

@end

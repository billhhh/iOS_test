//
//  ViewController.h
//  drawRect
//
//  Created by 黄 hshd1234 on 13-1-21.
//  Copyright (c) 2013年 呼喊. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end

//
//  MultiLines.h
//  PowerPlot
//
//  Created by Wolfram Schroers on 04.08.11.
//  Copyright 2011 Numerik & Analyse Schroers. All rights reserved.
//

#import "ExampleChartController.h"

@class WSChart;

@interface MultiLines : ExampleChartController

@property (nonatomic, retain) IBOutlet WSChart *chart;

@end

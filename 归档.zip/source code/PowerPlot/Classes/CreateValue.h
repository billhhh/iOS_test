//
//  CreateValue.h
//  PowerPlot
//
//  Created by Wolfram Schroers on 27.10.10.
//  Copyright 2010 Numerik & Analyse Schroers. All rights reserved.
//

#import "ExampleChartController.h"

@interface CreateValue : ExampleChartController

@end

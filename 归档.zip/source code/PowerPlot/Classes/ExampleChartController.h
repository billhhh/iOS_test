//
//  ExampleChartController.h
//  PowerPlot
//
//  Created by Wolfram Schroers on 1/29/12.
//  Copyright (c) 2012 Numerik & Analyse Schroers. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExampleChartController : UIViewController

@end

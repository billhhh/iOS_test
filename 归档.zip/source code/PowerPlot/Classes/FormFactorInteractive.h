//
//  FormFactorInteractive.h
//  PowerPlot
//
//  Created by Wolfram Schroers on 1/23/12.
//  Copyright (c) 2012 Numerik & Analyse Schroers. All rights reserved.
//

#import "ExampleChartController.h"
#import "PowerPlot.h"

@interface FormFactorInteractive : ExampleChartController
    <WSControllerGestureDelegate>

@end

//
//  ContourPlot.h
//  PowerPlot
//
//  Created by Wolfram Schroers on 25.11.10.
//  Copyright 2010 Numerik & Analyse Schroers. All rights reserved.
//

#import "ExampleChartController.h"

@interface ContourPlot : ExampleChartController

@end

//
//  BusinessModelGraph.h
//  PowerPlot
//
//  Created by Wolfram Schroers on 26.10.10.
//  Copyright 2010 Numerik & Analyse Schroers. All rights reserved.
//

#import "ExampleChartController.h"

@interface BusinessModelGraph : ExampleChartController

@end
